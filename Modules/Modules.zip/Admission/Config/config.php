<?php

return [
    'name' => 'Admission'
];
