<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\UserProfile\\Providers\\UserProfileServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\UserProfile\\Providers\\UserProfileServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);