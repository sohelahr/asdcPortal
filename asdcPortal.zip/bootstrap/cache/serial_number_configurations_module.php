<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SerialNumberConfigurations\\Providers\\SerialNumberConfigurationsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SerialNumberConfigurations\\Providers\\SerialNumberConfigurationsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);