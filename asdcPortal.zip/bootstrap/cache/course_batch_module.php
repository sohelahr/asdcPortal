<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CourseBatch\\Providers\\CourseBatchServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CourseBatch\\Providers\\CourseBatchServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);