<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Register\\Providers\\RegisterServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Register\\Providers\\RegisterServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);