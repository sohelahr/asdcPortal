<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DocumentList\\Providers\\DocumentListServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DocumentList\\Providers\\DocumentListServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);