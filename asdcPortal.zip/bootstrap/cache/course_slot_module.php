<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CourseSlot\\Providers\\CourseSlotServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CourseSlot\\Providers\\CourseSlotServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);