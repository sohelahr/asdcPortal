<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Admission\\Providers\\AdmissionServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Admission\\Providers\\AdmissionServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);