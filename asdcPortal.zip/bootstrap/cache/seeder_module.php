<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Seeder\\Providers\\SeederServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Seeder\\Providers\\SeederServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);