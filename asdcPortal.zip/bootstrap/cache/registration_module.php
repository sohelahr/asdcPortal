<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Registration\\Providers\\RegistrationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Registration\\Providers\\RegistrationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);