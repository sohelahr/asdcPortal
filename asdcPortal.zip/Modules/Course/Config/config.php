<?php

return [
    'name' => 'Course'
];
