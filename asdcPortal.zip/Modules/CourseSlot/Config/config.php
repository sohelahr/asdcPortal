<?php

return [
    'name' => 'CourseSlot'
];
