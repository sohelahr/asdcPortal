<?php

return [
    'name' => 'CourseBatch'
];
