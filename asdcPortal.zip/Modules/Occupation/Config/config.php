<?php

return [
    'name' => 'Occupation'
];
