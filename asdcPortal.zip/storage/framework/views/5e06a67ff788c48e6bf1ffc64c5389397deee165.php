<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->yieldContent('title'); ?>
    <!-- plugins:css -->
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">
    <link rel="stylesheet" href="<?php echo e(env('BACKEND_CDN_URL')); ?>/vendors/iconfonts/font-awesome/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(env('BACKEND_CDN_URL')); ?>/vendors/css/vendor.bundle.base.css">
    <link rel="stylesheet" href="<?php echo e(env('BACKEND_CDN_URL')); ?>/vendors/css/vendor.bundle.addons.css">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo e(env('BACKEND_CDN_URL')); ?>/css/style.css">
    <link rel="stylesheet" href="<?php echo e(env('BACKEND_CDN_URL')); ?>/css/custom.css">

    <!-- endinject -->
    <link rel="shortcut icon" href="<?php echo e(env('BACKEND_CDN_URL')); ?>/images/favicon.png"/>
    <style>
        body {
            font-family: 'Nunito', sans-serif;
        }
    </style>
</head>
<body>
    <div class="container-scroller">
        
        <?php echo $__env->make('layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container-fluid page-body-wrapper">
            
            <?php echo $__env->make('layouts.admin.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="main-panel">
                
                <div class="content-wrapper">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                
                <?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
    <script src="<?php echo e(env('BACKEND_CDN_URL')); ?>/vendors/js/vendor.bundle.base.js"></script> 
    <script src="<?php echo e(env('BACKEND_CDN_URL')); ?>/vendors/js/vendor.bundle.addons.js"></script>
    <script src="<?php echo e(env('BACKEND_CDN_URL')); ?>/js/off-canvas.js"></script>
    <script src="<?php echo e(env('BACKEND_CDN_URL')); ?>/js/hoverable-collapse.js"></script>
    <script src="<?php echo e(env('BACKEND_CDN_URL')); ?>/js/misc.js"></script>
    <script src="<?php echo e(env('BACKEND_CDN_URL')); ?>/js/settings.js"></script>
    <script src="<?php echo e(env('BACKEND_CDN_URL')); ?>/js/todolist.js"></script>

    <?php echo $__env->yieldContent('jcontent'); ?>
</body>
</html>
<?php /**PATH C:\xamppnew\htdocs\asdcPortal\resources\views/layouts/admin/app.blade.php ENDPATH**/ ?>