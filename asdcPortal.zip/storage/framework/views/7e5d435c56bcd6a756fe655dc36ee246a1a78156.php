
<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h3 class="page-title">
            Edit Admissions
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Edit Admissions</li>
            </ol>
        </nav>
    </div>
    <div class="card">
        
        <div class="card-body">
            <form action="<?php echo e(route('user_admission_edit',$admission->id)); ?>" method="POST" enctype="multipart/form-data"> 
                <?php echo csrf_field(); ?>       
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label">Student Name</label>
                            <input required type="text" class="form-control form-control-sm" name="firstname"
                                value="<?php echo e($student->name); ?>" disabled>
                                <input type="hidden" name="student_id" value="<?php echo e($student->id); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label">Roll No</label>
                            <input class="form-control form-control-sm" name="roll_no" type="text" value="<?php echo e($admission->roll_no); ?>" disabled>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label">Admission Form Number</label>
                            <input class="form-control form-control-sm" type="text" name="admission_form_number" value=<?php echo e($admission->admission_form_number); ?> disabled>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label">Course</label>

                            <select class="form-control" name="course_id" id="admission_course">
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($course->id); ?>" <?php if($course->id == $admission->course_id): ?>
                                        selected
                                    <?php endif; ?>><?php echo e($course->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label">Course Timing</label>

                            <select class="form-control" name="course_slot_id" id="course_slot">
                                <?php $__currentLoopData = $initial_course_slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseslot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($courseslot->id); ?>" <?php if($courseslot->id == $admission->courseslot_id): ?>
                                        selected
                                    <?php endif; ?>><?php echo e($courseslot->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label">Course Batch</label>

                            <select class="form-control" name="coursebatch_id" id="course_batch">
                                <?php if(count($initial_course_batches) > 0): ?>
                                    <?php $__currentLoopData = $initial_course_batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coursebatch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($coursebatch->id); ?>" <?php if($coursebatch->id == $admission->coursebatch_id): ?>
                                        selected
                                    <?php endif; ?>><?php echo e($coursebatch->batch_number); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <option>No Batches Found</option>
                                <?php endif; ?>
                            </select>

                        </div>
                    </div>
            
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Admission Remarks</label>
                            <textarea class="form-control" rows="7" name="admission_remarks"><?php echo e($admission->admission_remarks); ?></textarea>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                        <label class="form-label">Documents Submitted</label>
                        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="form-check form-check-primary">
                            <label class="form-check-label">
                              <input type="checkbox" class="form-check-input" name="document_<?php echo e($document->id); ?>"  
                                <?php if(in_array($document->id,$submitted_documents)): ?>
                                    checked
                                <?php endif; ?>
                                value="<?php echo e($document->id); ?>">
                              <?php echo e($document->name); ?>

                            <i class="input-helper"></i></label>
                          </div>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div> 
                      </div>
                </div>                                                         
                <button type="submit" class="btn btn-primary mr-2">Submit</button>
                <a class="btn btn-light" href="<?php echo e(url('admin/dashboard')); ?>">Cancel</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jcontent'); ?>
<script>
    
    $("#admission_course").on('change',function(){
        let course_id = $("#admission_course").val()
        $.ajax({
            type: "get",
            url: `<?php echo e(url('admission/getforminputs/${course_id}')); ?>`,
            success: function (response) {
                console.log(response)
                $("#course_slot").empty();
                $("#course_batch").empty();

                if(response.course_slots.length > 0){
                    $.each(response.course_slots, function (index, element) { 
                        $("#course_slot").append(`
                            <option value="${element.id}">${element.name}</option>
                        `);
                    });
                }
                else
                {
                    $("#course_slot").append(`
                            <option value="">Not Found</option>
                        `);
                }
                if(response.course_batches.length > 0){
                    $.each(response.course_batches, function (index, element) { 
                        $("#course_batch").append(`
                            <option value="${element.id}">${element.batch_number}</option>
                        `);
                    });
                }
                else
                {
                    $("#course_batch").append(`
                            <option value="">Not Found</option>
                        `);
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\asdcPortal\Modules/Admission\Resources/views/edit.blade.php ENDPATH**/ ?>