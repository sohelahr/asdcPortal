
<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h3 class="page-title">
            View Admission
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">View Admission</li>
            </ol>
        </nav>
    </div>
    <div class="card">
        
        <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label">Student Name</label>
                            <input required type="text" class="form-control form-control-sm" name="firstname"
                                value="<?php echo e($admission->Student->name); ?>" disabled> 
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label">Roll No</label>
                            <input class="form-control form-control-sm" name="roll_no" type="text" disabled value="<?php echo e($admission->roll_no); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label">Admission Form Number</label>
                            <input class="form-control form-control-sm" type="text" disabled name="admission_form_number" value="<?php echo e($admission->admission_form_number); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label">Course</label>
                            <input type="text" class="form-control-sm form-control" disabled value="<?php echo e($admission->Course->name); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label">Course Timing</label>
                            <input type="text" class="form-control-sm form-control" disabled value="<?php echo e($admission->CourseSlot->name); ?>">
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label">Course Batch</label>
                            <input type="text" class="form-control-sm form-control" disabled value="<?php echo e($admission->CourseBatch->batch_number); ?>">
                        </div>
                    </div>
            
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Admission Remarks</label>
                            <textarea class="form-control" rows="7" name="admission_remarks" disabled><?php echo e($admission->admission_remarks); ?></textarea>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                        <label class="form-label">Documents Submitted</label>
                        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="form-check form-check-primary">
                            <label class="form-check-label">
                              <input type="checkbox" class="form-check-input" <?php if(in_array($document->id,$documents_submitted)): ?> checked  <?php endif; ?> value="<?php echo e($document->id); ?>" disabled>
                              <?php echo e($document->name); ?>

                            <i class="input-helper"></i></label>
                          </div>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div> 
                      </div>
                </div>
                <div class="float-right">
                    <a type="button" class="btn btn-primary btn-icon-text" href="<?php echo e(route('print_admission_form',$admission->id)); ?>" target="_blank">
                          Print
                          <i class="fa fa-print btn-icon-append"></i>                                                                              
                    </a>                                                         
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jcontent'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\asdcPortal\Modules/Admission\Resources/views/view.blade.php ENDPATH**/ ?>