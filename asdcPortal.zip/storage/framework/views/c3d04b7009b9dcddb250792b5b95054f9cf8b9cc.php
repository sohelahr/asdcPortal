<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h3 class="page-title">
            Profiles
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">User Profiles</li>
            </ol>
        </nav>
    </div>
    <div class="card">
        
        <div class="card-body">
            
            <div class="table-responsive">
                <table class="table table-hover" id="userprofiles">
                    <thead>
                        <tr>
                            <th style="width: 30px">No</th>
                            <th>Name</th>
                            <th>Mobile</th>
                            <th>Qualification</th>
                            <th>Type</th>
                            <th>Edit</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                     <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Mobile</th>
                            <th>Qualification</th>
                            <th>Type</th>
                            <th>Edit</th>
                        </tr>
                     </tfoot>
                </table>
            </div>
        </div>
    </div>

    

    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jcontent'); ?>
<script>
        <?php if(\Illuminate\Support\Facades\Session::has('updated')): ?>
            $.toast({
                heading: 'Updated',
                text: 'Profile Was Successfully Updated',
                position:'top-right',
                icon: 'info',
                loader: true,        // Change it to false to disable loader
                loaderBg: '#9EC600'  // To change the background
            })
        <?php elseif(\Illuminate\Support\Facades\Session::has('error')): ?>
            $.toast({
                heading: 'Danger',
                text: 'Something Went Wrong ',
                position:'top-right',
                icon: 'danger',
                loader: true,        // Change it to false to disable loader
                loaderBg: '#9EC600'  // To change the background
            })
        <?php endif; ?>
    $(document).ready( function () {
    $('#userprofiles').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('user_profile_data')); ?>",
        columns:[
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
            {data: 'name',render:function(data,type,row){
                //this will be rendered from server just for demo here
                return "<a href='userprofile/admin/"+row.id+"/view'>"+row.name+"</a>"
                },
            name:"name"
            },
            {data: 'mobile',name:"mobile"},
            {data: 'qualification',name:"qualification"},
            {data:'type',render:function(data,type,row){
                //this will be rendered from server just for demo here
                console.log(data)
                if(data == "True")
                   return "<label class='badge badge-pill badge-success'>Registered</label>"
                else
                    return "<label class='badge badge-warning badge-pill'>Not Registered</label>"
                },
            name:'type'
            },
            {data: 'edit',render:function(type,data,row){
                return "<a href='/userprofile/admin/edit/"+row.id+"' class='btn btn-dark btn-rounded p-2 mr-2'><i class='fas fa-pencil-alt'></i></a>"
                },
            },
        ]
    });
} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\asdcPortal\Modules/UserProfile\Resources/views/admin_profile_list.blade.php ENDPATH**/ ?>