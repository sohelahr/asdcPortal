
<?php $__env->startSection('content'); ?>
    
    <div class="page-header">
        <h3 class="page-title">
            Profile Edit
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">User Profile Edit</li>
            </ol>
        </nav>
    </div>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('user_profile_edit',$userprofile->id)); ?>" method="POST" enctype="multipart/form-data">        
                    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                            <div class="p-5 bg-white border-b border-gray-200">
                                    <?php echo csrf_field(); ?>

                                    <p class="card-description text-black-50">
                                        Personal Info
                                    </p>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="form-label">First Name</label>

                                                <input required type="text" class="form-control form-control-sm" name="firstname"
                                                    value="<?php echo e($userprofile->firstname); ?>">

                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="form-label">Last Name</label>

                                                <input required type="text" class="form-control form-control-sm" name="lastname"
                                                    value="<?php echo e($userprofile->lastname); ?>">

                                            </div>
                                        </div>
                                        
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="form-label">Mobile Number</label>

                                                <input required type="text" class="form-control form-control-sm" name="mobile"
                                                    value="<?php echo e($userprofile->mobile); ?>">

                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="form-label">Gender</label>

                                                <select class="form-control" name="gender">
                                                    <option value="male" <?php if($userprofile->gender == "male"): ?>
                                                        selected
                                                        <?php endif; ?>>Male</option>
                                                    <option value="female" <?php if($userprofile->gender == "female"): ?>
                                                        selected
                                                        <?php endif; ?>>Female</option>
                                                </select>

                                            </div>
                                        </div>
                                    
                                    
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="form-label">Date of Birth</label>

                                                <div id="datepicker-popup" class="input-group date datepicker p-0 m-0">
                                                    <input required type="text" class="form-control form-control-sm" name="dob"
                                                        value="<?php echo e($userprofile->dob); ?>">
                                                    <span class="input-group-addon input-group-append border-left">
                                                        <i class="far fa-calendar input-group-text py-1 px-2"></i>
                                                    </span>
                                                </div>

                                            </div>
                                        </div>
                                        
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="form-label">Age</label>

                                                <input required type="text" class="form-control form-control-sm" name="age"
                                                    value="<?php echo e($userprofile->age); ?>">

                                            </div>
                                        </div>
                                        
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label class="form-label">Aadhaar Number</label>
                                                <input required type="text" class="form-control form-control-sm" name="aadhaar"
                                                    value="<?php echo e($userprofile->aadhaar); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label class="form-label">Blood Group</label>
                                                <input required type="text" class="form-control form-control-sm" name="blood_group"
                                                    value="<?php echo e($userprofile->blood_group); ?>">
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label class="form-label">Marital Status</label>

                                                <select class="form-control" name="marital_status">
                                                    <option value="single" <?php if($userprofile->marital_status == "single"): ?>
                                                        selected
                                                        <?php endif; ?>>Single</option>
                                                    <option value="married" <?php if($userprofile->marital_status == "married"): ?>
                                                        selected
                                                        <?php endif; ?>>Married</option>
                                                </select>

                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Photo <sub> (leave blank if dont want to change)</sub></label>
                                            <input type="file" name="photo" class="form-control-file">
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <div class="pt-3">
                        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                                <div class="p-5 bg-white border-b border-gray-200">

                                    <p class="card-description text-black-50">
                                        Address
                                    </p>
                                    <div class="row">
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label class="form-label">Home Type</label>

                                                <select class="form-control" name="home_type">
                                                    <option value="rented" <?php if($userprofile->home_type == "rented"): ?>
                                                        selected
                                                        <?php endif; ?>>Rented</option>
                                                    <option value="owned" <?php if($userprofile->home_type == "owned"): ?>
                                                        selected
                                                        <?php endif; ?>>Owned</option>
                                                </select>

                                            </div>
                                        </div>
        
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label class="form-label">House Name/Number</label>

                                                <input required type="text" class="form-control form-control-sm"
                                                    name="house_details" value="<?php echo e($userprofile->house_details); ?>">
                                            </div>

                                        </div>
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label class="form-label">Street/Locality</label>

                                                <input required type="text" class="form-control form-control-sm" name="street"
                                                    value="<?php echo e($userprofile->street); ?>">
                                            </div>

                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label class="form-label">Landmark</label>

                                                <input required type="text" class="form-control form-control-sm" name="landmark"
                                                    value="<?php echo e($userprofile->landmark); ?>">

                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label class="form-label">Pincode</label>

                                                <input required type="text" class="form-control form-control-sm" name="pincode"
                                                    value="<?php echo e($userprofile->pincode); ?>">
                                            </div>

                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label class="form-label">City</label>

                                                <input required type="text" class="form-control form-control-sm" name="city"
                                                    value="<?php echo e($userprofile->city); ?>">
                                            </div>

                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label class="form-label">State</label>
                                                
                                                <input required type="text" class="form-control form-control-sm" name="state"
                                                    value="<?php echo e($userprofile->state); ?>">
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                
                <div class="pt-3">
                    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                            <div class="p-5 bg-white border-b border-gray-200">

                                <p class="card-description text-black-50">
                                    Education
                                </p>    
                                <div class="row">
                                    
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Last Qualification</label>

                                            <select class="form-control " name="qualification_id">
                                                <?php $__currentLoopData = $qualifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qualification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($qualification->id); ?>" <?php if($qualification->id ==$userprofile->qualification_id): ?> selected <?php endif; ?>><?php echo e($qualification->name); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Qualification Specialization</label>

                                            <input required type="text" class="form-control form-control-sm"
                                                name="qualification_specilization"
                                                value="<?php echo e($userprofile->qualification_specilization); ?>"
                                                placeholder="ex: Science/Mechanical/IT">

                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label class="form-label">School/College Name</label>

                                            <input required type="text" class="form-control form-control-sm" name="school_name"
                                                value="<?php echo e($userprofile->school_name); ?>">

                                        </div>
                                    </div>
                                    
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="form-label">Qualification Status</label>

                                            <select class="form-control " name="qualification_status">
                                                <option value="Passed" <?php if($userprofile->qualification_status == "Passed"): ?>
                                                    selected <?php endif; ?>>Passed</option>
                                                <option value="Pursuing" <?php if($userprofile->qualification_status == "Pursuing"): ?>
                                                    selected <?php endif; ?>>Pursuing</option>
                                                <option value="Completed" <?php if($userprofile->qualification_status == "Completed"): ?>
                                                    selected <?php endif; ?>>Completed</option>
                                                <option value="Left Incomplete" <?php if($userprofile->qualification_status == "Left Incomplete"): ?> selected <?php endif; ?>>Left Incomplete</option>
                                                
                                                <option value="Failed" <?php if($userprofile->qualification_status == "Failed"): ?> selected <?php endif; ?>>Failed</option>

                                            </select>

                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label class="form-label">Occupation</label>

                                            <select class="form-control" name="occupation_id">
                                                <?php $__currentLoopData = $occupations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occupation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($occupation->id); ?>" <?php if($occupation->id == $userprofile->occupation_id): ?> selected <?php endif; ?>><?php echo e($occupation->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="pt-3 pb-12">
                    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                            <div class="p-5 bg-white border-b border-gray-200">

                                <p class="card-description text-black-50">
                                    Other Information
                                </p>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Father's/Gaurdian's Name</label>

                                            <input required type="text" class="form-control form-control-sm" name="father_name"
                                                value="<?php echo e($userprofile->father_name); ?>">
                                        </div>

                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Father's/Gaurdian's Mobile</label>

                                            <input required type="text" class="form-control form-control-sm"
                                                name="fathers_mobile" value="<?php echo e($userprofile->fathers_mobile); ?>">
                                        </div>

                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Father's/Gaurdian's Annual Income</label>

                                            <select class="form-control " name="fathers_income">
                                                <option value="0 to 1 lac" <?php if($userprofile->fathers_income == "0 to 1 lac"): ?>
                                                    selected <?php endif; ?>>0 to 1 lac</option>
                                                <option value="1 to 2 lacs" <?php if($userprofile->fathers_income == "1 to 2 lacs"): ?>
                                                    selected <?php endif; ?>>1 to 2 lacs</option>
                                                <option value="2 to 3 lacs" <?php if($userprofile->fathers_income == "2 to 3 lacs"): ?>
                                                    selected <?php endif; ?>>2 to 3 lacs</option>
                                                <option value="3 to 4 lacs" <?php if($userprofile->fathers_income == "3 to 4 lacs"): ?> selected <?php endif; ?>>3 to 4 lacs</option>
                                                
                                                <option value=">= 4 lacs" <?php if($userprofile->fathers_income == ">= 4 lacs"): ?> selected <?php endif; ?>>>= 4 lacs</option>

                                            </select>
                                        </div>

                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Father's/Gaurdian's Occupation</label>

                                            <input required type="text" class="form-control form-control-sm"
                                                name="father_occupation" value="<?php echo e($userprofile->father_occupation); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">How You Got To Know About Us</label>

                                            
                                            <select class="form-control " name="how_know_us">
                                                <option value="Social Media" <?php if($userprofile->how_know_us == "Social Media"): ?>
                                                    selected <?php endif; ?>>Social Media</option>
                                                <option value="Newspaper" <?php if($userprofile->how_know_us == "Newspaper"): ?>
                                                    selected <?php endif; ?>>Newspaper</option>
                                                <option value="From a Friend" <?php if($userprofile->how_know_us == "From a Friend"): ?>
                                                    selected <?php endif; ?>>From a Friend</option>
                                                <option value="From a relative" <?php if($userprofile->how_know_us == "From a relative"): ?> selected <?php endif; ?>>From a relative</option>
                                                
                                                <option value="Other" <?php if($userprofile->how_know_us == "Other"): ?> selected <?php endif; ?>>Other</option>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Any Comments</label>

                                            <textarea class="form-control" rows="7" name="comments">
                                                <?php echo e($userprofile->comments); ?>

                                            </textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    
                                </div>
                                <button type="submit" class="btn btn-primary mr-2">Submit</button><a class="btn btn-light"
                                    href="<?php echo e(url('admin/dashboard')); ?>">Cancel</a>
                            
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
    <?php $__env->startSection('jcontent'); ?>
    <script>
        $('#datepicker-popup').datepicker({
            format: 'yy/mm/dd',
            autoclose: true,
            todayHighlight: true
        });

    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\asdcPortal\Modules/UserProfile\Resources/views/admin_profile_edit.blade.php ENDPATH**/ ?>