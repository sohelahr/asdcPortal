
<?php $__env->startSection('content'); ?>
    
    <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-lg-4">
                      <div class="border-bottom text-center pb-4">
                        <img src="<?php echo e(asset('storage/app/profile_photos/'.$profile->photo)); ?>" alt="profile" class="img-lg rounded-circle mb-3">
                        <p><?php echo e($profile->Occupation->name); ?></p>
                        <div class="d-flex justify-content-between">
                          <button class="badge badge-info badge-pill"><i class="fas fa-birthday-cake"></i> <?php echo e($profile->dob); ?></button>
                          <button class="badge badge-danger badge-pill"><i class="fas fa-burn"></i> <?php echo e($profile->blood_group); ?></button>
                        </div>
                      </div>
                      <div class="border-bottom py-4">
                        <p>Education</p>
                        <div>
                          
                          <label class="badge badge-outline-dark"><?php echo e($profile->Qualification->name); ?></label>
                          <label class="badge badge-outline-dark"><?php echo e($profile->qualification_specilization); ?></label>
                          <label class="badge badge-outline-dark"><?php echo e($profile->school_name); ?></label>
                          <label class="badge badge-outline-dark"><?php echo e($profile->qualification_status); ?></label>
                        </div>                                                               
                      </div>
                      <div class="border-bottom pt-4 pb-2">
                        <p class="clearfix">
                          <span class="float-left">
                            Aadhaar
                          </span>
                          <span class="float-right text-muted">
                            <?php echo e($profile->aadhaar); ?>

                          </span>
                        </p>
                        <p class="clearfix">
                          <span class="float-left">
                            Marital Status
                          </span>
                          <span class="float-right text-muted">
                            <?php echo e($profile->marital_status); ?>

                          </span>
                        </p>
                      </div>
                      <div class=" border-bottom py-4 mb-1">
                        <p class="clearfix">
                          <span class="float-left">
                            Status
                          </span>
                          <span class="float-right text-muted">
                            Active
                          </span>
                        </p>
                        <p class="clearfix">
                          <span class="float-left">
                            Phone
                          </span>
                          <span class="float-right text-muted">
                            <?php echo e($profile->mobile); ?>

                          </span>
                        </p>
                        <p class="clearfix">
                          <span class="float-left">
                            Email
                          </span>
                          <span class="float-right text-muted">
                            <?php echo e($profile->User->email); ?>

                          </span>
                        </p>
                    </div>
                    <div class="border-bottom py-2">
                      <p class="clearfix">
                          <span class="float-left">
                            How did they Find Us
                          </span>
                          <span class="float-right text-muted">
                            <?php echo e($profile->how_know_us); ?>

                          </span>
                      </p>
                      <p class="clearfix">
                          <span class="float-left">
                            Registration Comments :
                          </span>
                      <p>
                        <p class="text-muted"><?php echo e($profile->comments); ?></p>
                    </div>
                  </div>
                    <div class="col-lg-8 pl-lg-5">
                      <div class="d-flex justify-content-between">
                        <div>
                          <h3><?php echo e($profile->firstname); ?> <?php echo e($profile->lastname); ?></h3>
                          <div class="d-flex align-items-center">
                            <h5 class="mb-0 mr-2 text-muted text-capitalize"><?php echo e($profile->gender); ?> (<?php echo e($profile->age); ?>)</h5>
                        </div>
                        <div class="profile-feed">
                            <div class="d-flex align-items-start profile-feed-item">
                            <img src="<?php echo e(url('/public/images/state_icon.png')); ?>" alt="profile"  height="50" width="50" class="rounded-circle">
                            <div class="ml-4">
                                <h5>
                                Address
                                </h5>
                                <p class=" text-muted mt-2 mb-0" style="width: 80vh">
                                    <?php echo e($profile->house_details); ?>, <?php echo e($profile->street); ?>, <?php echo e($profile->landmark); ?>, <br><?php echo e($profile->city); ?>,
                                    <?php echo e($profile->state); ?>, <?php echo e($profile->pincode); ?>

                                </p>
                            </div>
                            </div>
                            <div class="d-flex align-items-start profile-feed-item">
                              <img src="<?php echo e(url('/public/images/father-icon.png')); ?>" alt="profile" height="50" width="50" class="rounded-circle">
                              <div class="ml-3 col-7">
                                  <h5>
                                  Family
                                  </h5><p class="clearfix">
                                  <span class="float-left">
                                    Father/Gaurdian 
                                  </span>
                                  <span class="float-right text-muted">
                                    <?php echo e($profile->father_name); ?>

                                  </span>
                                </p>
                                <p class="clearfix">
                                  <span class="float-left">
                                    Occupation
                                  </span>
                                  <span class="float-right text-muted">
                                    <?php echo e($profile->father_occupation); ?>

                                  </span>
                                </p>
                                <p class="clearfix">
                                  <span class="float-left">
                                    Mobile
                                  </span>
                                  <span class="float-right text-muted">
                                    <?php echo e($profile->fathers_mobile); ?>

                                  </span>
                                </p>
                                
                                <p class="clearfix">
                                  <span class="float-left">
                                    Income
                                  </span>
                                  <span class="float-right text-muted">
                                    <?php echo e($profile->fathers_income); ?>

                                  </span>
                                </p>
                              </div>
                              </div>
                            </div>
                            <div class="profile-feed-item">
                              <div>
                                <h5>User Registrations</h5>
                                <div class="row ">
                                  <div class="col-12">
                                  <table class="table" id="userregistration">
                                      <thead>
                                          <tr>
                                              <th>Course Name</th>
                                              <th>Course Timing</th>
                                              <th>Date</th>
                                              <th>Status</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                      </tbody>
                                  </table>
                                  </div>
                                </div>
                              </div>
                            </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jcontent'); ?>
<script>
    
    $(document).ready( function () {
    $('#userregistration').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('profile_registrations',$profile->id)); ?>",
        columns:[
            {data: 'course_name',name:"course_name"},
            {data: 'course_slot',name:"course_slot"},
            {data: 'date',name:"date"},
            {data:'status',render:function(type,data,row){
                if(row.status == "1")
                    return "<label class='badge badge-warning badge-pill'>Applied</label>"
                else if(row.status == "2")
                    return "<label class='badge badge-success badge-pill'>Admitted</label>"
                else if(row.status == "3")
                    return "<label class='badge badge-danger badge-pill'>Expired</label>"
                },
            name:'status'
            },
        ]
    });
} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\asdcPortal\Modules/UserProfile\Resources/views/admin_user_profile.blade.php ENDPATH**/ ?>