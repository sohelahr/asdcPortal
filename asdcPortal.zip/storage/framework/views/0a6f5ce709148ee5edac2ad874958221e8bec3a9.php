<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h5 class="font-semibold text-m text-gray-800 leading-tight">
            <?php echo e(__('My Courses')); ?>

        </h5>
     <?php $__env->endSlot(); ?>

    <div id="complete_profile" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title text-danger" id="my-modal-title">Notice : </h3>
                </div>
                <div class="modal-body">
                    <h5>To enroll in a course, please complete your profile.</h5>
                </div>
                <div class="modal-footer">
                    <a class="btn btn-warning" href="<?php echo e(route('profile_update')); ?>">Complete Profile</a>
                </div>
            </div>
        </div>
    </div>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    
                    <div class="float-right">
                        <a href="<?php echo e(route('user_registration_create')); ?>">
                        <button class="btn btn-info btn-icon-text" >
                            Enroll In A Course
                            <i class="fa fa-plus btn-icon-prepend"></i>
                        </button>
                        </a>
                    </div>
                    <div class="pt-5 mt-6">
                        <table class="table table-hover" id="registrations">
                        <thead>
                            <tr>
                                <th>Course Name</th>
                                <th>Course Timing</th>
                                <th>Registered On</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Course Name</th>
                                <th>Course Timing</th>
                                <th>Registered On</th>
                                <th>Status</th>
                            </tr>
                        </tfoot>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->startSection('jcontent'); ?>
    <script>
        <?php if(! Auth::User()->UserProfile->is_profile_completed): ?>
            $("#complete_profile").modal({
                backdrop: 'static',
                keyboard: false,
                show:true,
            })
        <?php endif; ?>
        <?php if(\Illuminate\Support\Facades\Session::has('profile_complete')): ?>    
                $.toast({
                    heading: 'Profile Complete',
                    text: 'Please Contact admin to make changes to your profile',
                    position:'top-right',
                    icon: 'danger',
                    loader: true,        // Change it to false to disable loader
                    loaderBg: '#9EC600'  // To change the background
                })
            <?php elseif(\Illuminate\Support\Facades\Session::has('profile_not_complete')): ?>
                $.toast({
                    heading: 'Danger',
                    text: 'First Update Your Profile',
                    position:'top-center',
                    icon: 'danger',
                    loader: true,        // Change it to false to disable loader
                    loaderBg: '#9EC600'  // To change the background
                })
                
            <?php elseif(\Illuminate\Support\Facades\Session::has('profile_updated')): ?>
                $.toast({
                    heading: 'success',
                    text: 'Profile was successfully updated',
                    position:'top-center',
                    icon: 'success',
                    loader: true,        // Change it to false to disable loader
                    loaderBg: '#9EC600'  // To change the background
                })
            <?php elseif(\Illuminate\Support\Facades\Session::has('registered')): ?>
                $.toast({
                    heading: 'Registered',
                    text: 'You have successfully registered For a course',
                    position:'top-right',
                    icon: 'success',
                    loader: true,        // Change it to false to disable loader
                    loaderBg: '#9EC600'  // To change the background
                })
                
            <?php elseif(\Illuminate\Support\Facades\Session::has('already_registered')): ?>
                $.toast({
                    heading: 'Warning',
                    text: 'You have already registered for two courses please visit the center before applying for more',
                    position:'top-right',
                    icon: 'warning',
                    loader: false,        // Change it to false to disable loader
                    loaderBg: '#9EC600'  // To change the background
                })
                
            <?php elseif(\Illuminate\Support\Facades\Session::has('error')): ?>
                $.toast({
                    heading: 'Danger',
                    text: 'Something went wrong ',
                    position:'top-right',
                    icon: 'danger',
                    loader: true,        // Change it to false to disable loader
                    loaderBg: '#9EC600'  // To change the background
                })
            <?php endif; ?>
        $(document).ready( function () {
        $('#registrations').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('user_registrations')); ?>",
            columns:[
                /* {data: 'student_name', name: 'student_name'}, */
                {data: 'course_name',name:"course_name"},
                {data: 'course_slot',name:"course_slot"},
                {data: 'date',name:"date"},
                {data:'status',render:function(type,data,row){
                    if(row.status == "1")
                        return "<label class='badge badge-warning badge-pill'>Applied</label>"
                    else if(row.status == "2")
                        return "<label class='badge badge-success badge-pill'>Admitted</label>"
                    else if(row.status == "3")
                        return "<label class='badge badge-danger badge-pill'>Expired</label>"
                    },
                name:'status'
                },
            ]
        });
        });
    </script>
<?php $__env->stopSection(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xamppnew\htdocs\asdcPortal\resources\views/dashboard.blade.php ENDPATH**/ ?>