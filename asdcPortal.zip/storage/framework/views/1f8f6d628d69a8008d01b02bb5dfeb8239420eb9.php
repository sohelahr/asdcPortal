<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h3 class="page-title">
            Registrations
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Registrations</li>
            </ol>
        </nav>
    </div>
    <div class="card">
        
        <div class="card-body">
            
            <div class="table-responsive">
                         <table class="table table-hover" id="registrations">
                    <thead>
                        <tr>
                            <th style="width: 30px">No</th>
                            <th>Student Name</th>
                            <th>Course Name</th>
                            <th>Course Timing</th>
                            <th>Registered On</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                     <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Student Name</th>
                            <th>Course Name</th>
                            <th>Course Timing</th>
                            <th>Registered On</th>
                            <th>Action</th>
                        </tr>
                     </tfoot>
                </table>
                </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('jcontent'); ?>
<script>
    
    $(document).ready( function () {
    $('#registrations').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('all_registrations')); ?>",
        columns:[
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
            {data: 'student_name', name: 'student_name'},
            {data: 'course_name',name:"course_name"},
            {data: 'course_slot',name:"course_slot"},
            {data: 'date',name:"date"},
            {data:'Action',render:function(type,data,row){
                    return "<button class='badge badge-primary badge-pill'>Admit</button>"
                },name:'action'}
        ]
    });
} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\asdcPortal\Modules/Registration\Resources/views/index.blade.php ENDPATH**/ ?>