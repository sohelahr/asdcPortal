<?php

return [
    'name' => 'Qualification'
];
