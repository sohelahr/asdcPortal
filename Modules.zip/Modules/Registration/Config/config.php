<?php

return [
    'name' => 'Registration'
];
