<?php

return [
    'name' => 'SerialNumberConfigurations'
];
