<?php

return [
    'name' => 'DocumentList'
];
